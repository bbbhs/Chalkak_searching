import { Outlet, useNavigate, useLocation } from "react-router";
import { Home, Camera, Heart, Settings } from "lucide-react";

export function Layout() {
  const navigate = useNavigate();
  const location = useLocation();

  const navItems = [
    { icon: Home, label: "홈", path: "/home" },
    { icon: Camera, label: "촬영", path: "/camera" },
    { icon: Heart, label: "찜", path: "/favorites" },
    { icon: Settings, label: "설정", path: "/settings" },
  ];

  return (
    <div className="h-screen max-h-[852px] bg-white flex flex-col w-[393px] mx-auto overflow-hidden">
      <main className="flex-1 overflow-auto">
        <Outlet />
      </main>

      {/* Bottom Navigation */}
      <nav className="shrink-0 bg-white/80 backdrop-blur-xl border-t border-slate-100 px-4 py-1.5 pb-4 z-50">
        <div className="flex items-center justify-between">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            return (
              <button
                key={item.path}
                onClick={() => navigate(item.path)}
                className={`relative flex flex-col items-center gap-1 py-1 px-3 transition-all duration-300 ${
                  isActive ? "scale-110" : "opacity-60 grayscale hover:opacity-100"
                }`}
              >
                <div className={`p-1.5 rounded-xl transition-all duration-300 ${
                  isActive
                    ? item.label === "찜"
                      ? "bg-red-50 text-red-500 shadow-inner"
                      : "bg-[#B5DEFF]/10 text-[#B5DEFF] shadow-inner"
                    : "text-slate-400"
                }`}>
                  <Icon className={`w-5 h-5 stroke-[2.5px] ${isActive && item.label === "찜" ? "fill-red-500" : ""}`} />
                </div>
                <span
                  className={`text-[9px] tracking-tighter uppercase font-black transition-colors ${
                    isActive
                      ? item.label === "찜"
                        ? "text-red-500"
                        : "text-[#B5DEFF]"
                      : "text-slate-400"
                  }`}
                >
                  {item.label}
                </span>

                {isActive && (
                  <div className={`absolute -top-2 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full ${
                    item.label === "찜"
                      ? "bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.8)]"
                      : "bg-[#B5DEFF] shadow-[0_0_8px_rgba(138,197,227,0.8)]"
                  }`} />
                )}
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
