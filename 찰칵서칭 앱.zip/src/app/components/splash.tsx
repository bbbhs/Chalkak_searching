export function Splash() {
  return (
    <div className="fixed inset-0 z-[100] bg-[#B5DEFF] flex flex-col items-center justify-center w-[393px] max-h-[852px] mx-auto animate-in fade-in duration-500">
      <svg
        width={150}
        height={151}
        viewBox="0 0 150 151"
        fill="none"
        className="drop-shadow-lg"
      >
        <circle cx="75" cy="75" r="60" fill="white" />
        <path
          d="M60 65 L70 75 L90 55"
          stroke="#B5DEFF"
          strokeWidth="8"
          strokeLinecap="round"
          strokeLinejoin="round"
          fill="none"
        />
        <rect x="50" y="90" width="50" height="30" rx="5" fill="white" />
        <rect x="55" y="95" width="40" height="20" rx="3" fill="#B5DEFF" />
      </svg>
      <p
        className="text-white tracking-tight mt-6"
        style={{ fontFamily: "'Jalnan2', sans-serif", fontSize: 32 }}
      >
        찰칵서칭
      </p>
    </div>
  );
}
