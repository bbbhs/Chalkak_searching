import { useNavigate } from "react-router";

type LogoProps = {
  size?: number;
  showText?: boolean;
  className?: string;
};

export function Logo({ size = 24, showText = true, className = "" }: LogoProps) {
  const navigate = useNavigate();
  return (
    <button
      onClick={() => navigate("/home")}
      className={`flex items-center gap-1.5 active:scale-95 transition-transform ${className}`}
    >
      <svg
        width={size}
        height={size}
        viewBox="0 0 32 32"
        fill="none"
        className="shrink-0"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <linearGradient id="logoGrad" x1="0" y1="0" x2="32" y2="32" gradientUnits="userSpaceOnUse">
            <stop offset="0" stopColor="#B5DEFF" />
            <stop offset="1" stopColor="#5FA8CC" />
          </linearGradient>
        </defs>
        <rect x="2" y="7" width="28" height="20" rx="6" fill="url(#logoGrad)" />
        <rect x="11" y="4" width="10" height="5" rx="1.5" fill="url(#logoGrad)" />
        <circle cx="16" cy="17" r="6.5" fill="white" />
        <circle cx="15.2" cy="16.2" r="3.2" fill="none" stroke="#B5DEFF" strokeWidth="1.6" />
        <line x1="17.6" y1="18.6" x2="20.2" y2="21.2" stroke="#B5DEFF" strokeWidth="1.8" strokeLinecap="round" />
        <circle cx="14.2" cy="15.2" r="0.9" fill="white" />
        <circle cx="25.5" cy="11.5" r="1.2" fill="white" />
      </svg>
      {showText && (
        <span
          className="text-slate-900 tracking-tight leading-none"
          style={{ fontSize: size * 0.6, fontFamily: "'Jalnan2', sans-serif" }}
        >
          찰칵서칭
        </span>
      )}
    </button>
  );
}
