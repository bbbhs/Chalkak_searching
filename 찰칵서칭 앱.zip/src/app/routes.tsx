import { createBrowserRouter } from "react-router";
import { Onboarding } from "./pages/onboarding";
import { Home } from "./pages/home";
import { Camera } from "./pages/camera";
import { Loading } from "./pages/loading";
import { Result } from "./pages/result";
import { Favorites } from "./pages/favorites";
import { Settings } from "./pages/settings";
import { ProfileEdit } from "./pages/profile-edit";
import { Layout } from "./components/layout";

export const router = createBrowserRouter([
  {
    path: "/",
    children: [
      {
        index: true,
        element: <Onboarding />,
      },
      {
        element: <Layout />,
        children: [
          {
            path: "home",
            element: <Home />,
          },
          {
            path: "camera",
            element: <Camera />,
          },
          {
            path: "favorites",
            element: <Favorites />,
          },
          {
            path: "settings",
            element: <Settings />,
          },
          {
            path: "settings/profile",
            element: <ProfileEdit />,
          },
        ],
      },
    ],
  },
  {
    path: "/loading",
    element: <Loading />,
  },
  {
    path: "/result/:id",
    element: <Result />,
  },
]);
