// Figma Make Edge Function 베이스 URL
// VITE_SERVER_URL이 있으면 사용, 없으면 Supabase 프로젝트 ID로 구성
const BASE =
  (import.meta.env.VITE_SERVER_URL as string | undefined) ??
  "https://ayqivkwgrbtpsclpbwxl.supabase.co/functions/v1/server";

export const SERVER = `${BASE}/make-server-390d39c1`;

export interface PriceResult {
  currentPrice: number | null;
  priceHistory: { date: string; price: number }[];
  source: "naver" | "cache_only";
  updatedAt?: string;
}

export async function fetchProductPrice(
  productId: string,
  name: string,
  model: string
): Promise<PriceResult | null> {
  try {
    const url = `${SERVER}/price/${productId}?name=${encodeURIComponent(name)}&model=${encodeURIComponent(model)}`;
    const res = await fetch(url, { signal: AbortSignal.timeout(8000) });
    if (!res.ok) return null;
    return (await res.json()) as PriceResult;
  } catch {
    return null;
  }
}
