import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface UserProfile {
  name: string;
  email: string;
  phone: string;
  profileImage: string;
}

interface UserStore {
  profile: UserProfile;
  updateProfile: (updates: Partial<UserProfile>) => void;
}

export const useUserStore = create<UserStore>()(
  persist(
    (set) => ({
      profile: {
        name: "김지우",
        email: "jiwoo.kim@example.com",
        phone: "010-1234-5678",
        profileImage: "https://images.unsplash.com/photo-1635353692890-80a6b95add47?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxrb3JlYW4lMjBwZXJzb24lMjBwcm9maWxlJTIwcGhvdG98ZW58MXx8fHwxNzc2MjM1MDA2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      },
      updateProfile: (updates) => 
        set((state) => ({
          profile: { ...state.profile, ...updates },
        })),
    }),
    {
      name: 'user-storage',
    }
  )
);
