import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface SearchHistoryItem {
  id: string;
  name: string;
  model: string;
  image: string;
  currentPrice: number;
  prevPrice: number;
  priceStatus: 'low' | 'average' | 'high';
  timestamp: number;
  matchRate: number;
}

interface SearchHistoryState {
  history: SearchHistoryItem[];
  addItem: (item: SearchHistoryItem) => void;
  removeItem: (id: string) => void;
  clearHistory: () => void;
}

export const useSearchStore = create<SearchHistoryState>()(
  persist(
    (set) => ({
      history: [],
      addItem: (newItem) => 
        set((state) => {
          // 중복 아이템 제거 (최신화)
          const filtered = state.history.filter(item => item.id !== newItem.id);
          // 최대 10개까지만 유지
          return { history: [newItem, ...filtered].slice(0, 10) };
        }),
      removeItem: (id) => 
        set((state) => ({ 
          history: state.history.filter(item => item.id !== id) 
        })),
      clearHistory: () => set({ history: [] }),
    }),
    {
      name: 'search-history-storage',
    }
  )
);
