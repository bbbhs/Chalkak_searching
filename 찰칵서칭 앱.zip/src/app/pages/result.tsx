import { useState, useMemo, useEffect } from "react";
import { useNavigate, useParams } from "react-router";
import {
  ArrowLeft,
  ExternalLink,
  Heart,
  TrendingDown,
  Calendar,
  DollarSign,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
} from "lucide-react";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import { getProductById } from "../data/products";
import { Logo } from "../components/logo";
import { toast } from "sonner";
import { fetchProductPrice } from "../lib/server";

export function Result() {
  const navigate = useNavigate();
  const { id } = useParams();
  const [isFavorite, setIsFavorite] = useState(false);
  const [livePrice, setLivePrice] = useState<number | null>(null);
  const [liveHistory, setLiveHistory] = useState<{ date: string; price: number }[] | null>(null);
  const [priceLoading, setPriceLoading] = useState(false);

  // 찜 상태 확인 및 업데이트 로직 추가
  useEffect(() => {
    if (id) {
      const saved = localStorage.getItem("user_favorites");
      if (saved) {
        const favorites = JSON.parse(saved);
        setIsFavorite(favorites.some((item: any) => item.id === id));
      }
    }
  }, [id]);

  const toggleFavorite = () => {
    if (!productInfo) return;
    
    const saved = localStorage.getItem("user_favorites");
    let favorites = saved ? JSON.parse(saved) : [];
    
    if (isFavorite) {
      favorites = favorites.filter((item: any) => item.id !== id);
      toast.success("찜한 목록에서 삭제되었습니다.");
    } else {
      const newItem = {
        id: productInfo.id,
        name: productInfo.name,
        model: productInfo.model,
        image: productInfo.image,
        currentPrice: productInfo.currentPrice,
        prevPrice: productInfo.avgPrice,
        priceStatus: productInfo.priceStatus,
        savedDate: new Date().toLocaleDateString(),
      };
      favorites.push(newItem);
      toast.success("찜한 목록에 추가되었습니다!", {
        icon: <Heart className="w-4 h-4 fill-red-500 text-red-500" />
      });
    }
    
    localStorage.setItem("user_favorites", JSON.stringify(favorites));
    setIsFavorite(!isFavorite);
  };

  // ID로 제품 데이터 가져오기
  const productInfo = useMemo(() => getProductById(id || "1"), [id]);

  // 네이버 쇼핑 실시간 가격 fetch
  useEffect(() => {
    if (!productInfo) return;
    let cancelled = false;
    setPriceLoading(true);
    fetchProductPrice(productInfo.id, productInfo.name, productInfo.model).then((result) => {
      if (cancelled) return;
      setPriceLoading(false);
      if (!result) return;
      if (result.currentPrice !== null) setLivePrice(result.currentPrice);
      if (result.priceHistory.length > 0) setLiveHistory(result.priceHistory);
    });
    return () => { cancelled = true; };
  }, [productInfo?.id]);

  const currentPrice = livePrice ?? productInfo?.currentPrice ?? 0;

  const chartData = useMemo(() => {
    if (liveHistory && liveHistory.length > 0) return liveHistory;
    if (!productInfo) return [];
    return productInfo.priceHistory;
  }, [productInfo, liveHistory]);

  if (!productInfo) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-500 mb-4">제품을 찾을 수 없습니다</p>
          <Button onClick={() => navigate("/home")}>홈으로 돌아가기</Button>
        </div>
      </div>
    );
  }

  const isGoodPrice = currentPrice <= productInfo.avgPrice;
  const priceDiff = currentPrice - productInfo.avgPrice;
  const priceDiffPercent = ((priceDiff / productInfo.avgPrice) * 100).toFixed(1);

  return (
    <div className="h-screen max-h-[852px] w-[393px] mx-auto overflow-hidden bg-gray-50 flex flex-col relative">
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-xl px-4 py-2 flex items-center justify-between border-b border-slate-100 shrink-0">
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate("/home")}
            className="w-9 h-9 bg-slate-50 rounded-lg flex items-center justify-center hover:bg-slate-100 active:scale-90 transition-all shadow-sm border border-slate-100"
          >
            <ArrowLeft className="w-4 h-4 text-slate-600" />
          </button>
          <Logo size={22} />
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={toggleFavorite}
            className={`w-9 h-9 rounded-lg flex items-center justify-center transition-all shadow-sm border ${
              isFavorite ? "bg-red-50 border-red-100 text-red-500 scale-110" : "bg-white border-slate-100 text-slate-400"
            }`}
          >
            <Heart className={`w-4 h-4 ${isFavorite ? "fill-red-500" : ""}`} />
          </button>
        </div>
      </div>

      <div className="flex-1 min-h-0 overflow-hidden flex flex-col">
        {/* Product Image Section */}
        <div className="bg-white px-4 pt-2 pb-3 relative overflow-hidden shrink-0">
          <div className="absolute top-0 left-0 w-full h-full bg-slate-50/50" />
          <div className="relative z-10 w-full max-w-[130px] aspect-square mx-auto bg-white rounded-[20px] overflow-hidden shadow-lg shadow-slate-200 border-2 border-white group">
            <ImageWithFallback
              src={productInfo.image}
              alt={productInfo.name}
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
            />
            {/* Status Floating Badge */}
            <div className={`absolute top-3 right-3 px-2 py-1 rounded-lg font-black text-[8px] uppercase tracking-widest shadow-md ${
              isGoodPrice ? "bg-green-500 text-white" : "bg-orange-500 text-white"
            }`}>
              {isGoodPrice ? "LOWEST PRICE" : "WATCHING"}
            </div>
          </div>
        </div>

        {/* Product Info Card */}
        <div className="px-3 -mt-2 relative z-20 shrink-0">
          <div className="bg-white rounded-[20px] p-3 shadow-lg shadow-slate-200 border border-slate-50 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 bg-[#B5DEFF]/5 rounded-full -mr-12 -mt-12 blur-2xl" />
            <div className="relative z-10">
              <div className="flex flex-col mb-1.5">
                <span className="text-[8px] font-black text-[#B5DEFF] uppercase tracking-[0.2em]">{productInfo.model}</span>
                <h3 className="font-black text-sm text-slate-900 leading-tight tracking-tight">{productInfo.name}</h3>
              </div>

              <div className="flex items-end gap-0.5 mb-2 leading-none">
                <span className="text-lg font-black text-slate-900 leading-none">
                  {currentPrice.toLocaleString()}
                </span>
                <span className="text-xs font-bold text-slate-400 leading-none pb-[2px]">원</span>
                {priceLoading && (
                  <RefreshCw className="w-3 h-3 text-[#B5DEFF] ml-1.5 mb-[3px] animate-spin" />
                )}
                {!priceLoading && livePrice !== null && (
                  <span className="text-[9px] font-black text-green-500 bg-green-50 px-1.5 py-0.5 rounded-md ml-1.5 mb-[3px]">
                    실시간
                  </span>
                )}
              </div>

              {/* Enhanced Price Status Badge */}
              {isGoodPrice ? (
                <div className="bg-green-50 rounded-[14px] p-2 flex items-center gap-2 border border-green-100">
                  <div className="w-7 h-7 bg-white rounded-lg flex items-center justify-center shrink-0 shadow-sm">
                    <CheckCircle2 className="w-5 h-5 text-green-500" />
                  </div>
                  <div>
                    <p className="font-black text-green-900 text-xs leading-tight">구매 적극 추천!</p>
                    <p className="text-[10px] font-bold text-green-600 mt-0.5 opacity-80">
                      평균가 대비 {Math.abs(Number(priceDiffPercent))}% 저렴
                    </p>
                  </div>
                </div>
              ) : (
                <div className="bg-orange-50 rounded-[14px] p-2 flex items-center gap-2 border border-orange-100">
                  <div className="w-7 h-7 bg-white rounded-lg flex items-center justify-center shrink-0 shadow-sm">
                    <AlertCircle className="w-5 h-5 text-orange-500" />
                  </div>
                  <div>
                    <p className="font-black text-orange-900 text-xs leading-tight">가격 주시 중</p>
                    <p className="text-[10px] font-bold text-orange-600 mt-0.5 opacity-80">
                      {Math.abs(Number(priceDiffPercent))}% 하락 시 알림
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Chart Section */}
        <div className="px-3 mt-2 shrink-0">
          <div className="bg-white rounded-[18px] p-2.5 shadow-lg shadow-slate-200 border border-slate-50">
            <div className="flex items-center justify-between mb-1.5">
              <h4 className="font-black text-[11px] text-slate-900 tracking-tight">가격 변동 추이</h4>
              <div className="flex items-center gap-1">
                <div className="w-1 h-1 bg-[#B5DEFF] rounded-full" />
                <span className="text-[8px] font-black text-slate-400 uppercase">3 Months</span>
              </div>
            </div>

            <div className="h-[110px] w-full">
              <ResponsiveContainer key={`rc-${productInfo?.id}`} width="100%" height="100%" id={`rc-${productInfo?.id}`}>
                <LineChart key={`chart-${productInfo?.id}`} data={chartData} id={`chart-${productInfo?.id}`}>
                  <CartesianGrid key="grid-main" vertical={false} strokeDasharray="3 3" stroke="#f1f5f9" />
                  <XAxis
                    key="xaxis-main"
                    dataKey="date"
                    axisLine={false}
                    tickLine={false}
                    tick={{ fontSize: 10, fontWeight: 700, fill: '#cbd5e1' }}
                    dy={10}
                  />
                  <YAxis
                    key="yaxis-main"
                    axisLine={false}
                    tickLine={false}
                    tick={{ fontSize: 10, fontWeight: 700, fill: '#cbd5e1' }}
                    tickFormatter={(val) => `${(val / 10000).toFixed(0)}만`}
                  />
                  <Tooltip
                    key="tooltip-main"
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        return (
                          <div key="tooltip-content" className="bg-slate-900 text-white p-3 rounded-xl shadow-2xl border border-slate-800 text-xs">
                            <p className="font-black mb-1 text-[10px] text-slate-400 uppercase tracking-widest">{payload[0].payload.date}</p>
                            <p className="font-bold text-[#B5DEFF] text-sm">{payload[0].value?.toLocaleString()}원</p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Line
                    key="line-main"
                    type="monotone"
                    dataKey="price"
                    stroke="#B5DEFF"
                    strokeWidth={4}
                    dot={{ fill: "#fff", stroke: "#B5DEFF", strokeWidth: 3, r: 5 }}
                    activeDot={{ r: 8, strokeWidth: 0, fill: "#B5DEFF" }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Stats Section */}
        <div className="px-3 mt-2 shrink-0">
          <div className="grid grid-cols-2 gap-2">
            <div className="bg-slate-900 rounded-[16px] px-3 py-2 text-white relative overflow-hidden min-w-0">
              <div className="relative z-10">
                <p className="text-[8px] font-black text-slate-400 uppercase tracking-[0.1em] whitespace-nowrap">평균가</p>
                <p className="font-black flex items-end gap-0.5 leading-none mt-1">
                  <span className="text-sm leading-none">{productInfo.avgPrice.toLocaleString()}</span>
                  <span className="text-[9px] font-bold text-slate-500 leading-none pb-[1px]">원</span>
                </p>
              </div>
              <div className="absolute top-[-20%] right-[-10%] w-10 h-10 bg-white/5 rounded-full blur-xl" />
            </div>
            <div className="bg-white rounded-[16px] px-3 py-2 shadow-md shadow-slate-200 border border-slate-100 min-w-0">
              <p className="text-[8px] font-black text-slate-400 uppercase tracking-[0.1em] whitespace-nowrap">역대 최저가</p>
              <p className="font-black text-green-600 flex items-end gap-0.5 leading-none mt-1">
                <span className="text-sm leading-none">{productInfo.lowestPrice.toLocaleString()}</span>
                <span className="text-[9px] font-bold text-gray-400 leading-none pb-[1px]">원</span>
              </p>
            </div>
          </div>
        </div>

        {/* Floating Action Buttons */}
        <div className="absolute bottom-16 right-3 flex flex-col gap-2 z-40">
          <button
            onClick={() => {
              const q = encodeURIComponent(`${productInfo.name} ${productInfo.model}`);
              window.open(`https://www.coupang.com/np/search?q=${q}`, "_blank");
            }}
            className="w-10 h-10 bg-[#B5DEFF] text-white rounded-[14px] shadow-[0_8px_16px_rgba(138,197,227,0.4)] flex items-center justify-center hover:scale-110 active:scale-95 transition-all group"
            title="쿠팡에서 보기"
          >
            <ExternalLink className="w-4 h-4 group-hover:rotate-12 transition-transform" />
          </button>
        </div>
      </div>
    </div>
  );
}