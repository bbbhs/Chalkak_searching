import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router";
import { Camera as CameraIcon, Upload, X, CheckCircle2, Search, Sparkles, Link as LinkIcon, AlertCircle, Tag, Cpu, ScanLine, Database, Brain } from "lucide-react";
import { getProductById, products, Product } from "../data/products";
import { motion, AnimatePresence } from "motion/react";
import { toast } from "sonner";
import { SERVER } from "../lib/server";

type AnalysisMode = "image" | "link";

/**
 * 서버(Edge Function)를 통해 Gemini Vision으로 이미지 인식.
 * API 키는 서버에서만 사용 — 브라우저에 노출되지 않음.
 */
async function analyzeWithGeminiVision(
  dataUrl: string
): Promise<{ id: string; confidence: number } | null> {
  const res = await fetch(`${SERVER}/recognize`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ image: dataUrl }),
    signal: AbortSignal.timeout(15000),
  });

  if (!res.ok) return null;

  const data = await res.json() as { id?: string; confidence?: number; error?: string };
  if (data.error || !data.id) return null;

  const validId = products.find((p) => p.id === String(data.id));
  if (!validId) return null;

  return { id: String(data.id), confidence: data.confidence ?? 80 };
}

// 파일명 키워드 → 제품 ID 매핑 (Claude 실패 시 폴백)
function recognizeFromFilename(filename: string): string | null {
  const s = filename.toLowerCase().replace(/[\s_\-\.]/g, "");

  const rules: [string[], string][] = [
    [["roborock", "로보락", "s8pro", "s8proultra"], "2"],
    [["dyson", "다이슨", "airwrap", "hs05", "에어랩"], "3"],
    [["bespoke", "rf85", "비스포크"], "4"],
    [["philips", "필립스", "hd9252", "에어프라이어", "airfryer", "fryer"], "6"],
    [["coway", "코웨이", "chp241", "정수기", "waterpurifier"], "7"],
    [["irobot", "아이로봇", "roomba", "j7558"], "8"],
    [["lgtromm", "lgtromb", "rh16", "건조기", "dryer"], "9"],
    [["무풍", "af17", "aircon", "에어컨", "airconditioner"], "10"],
    [["breville", "브레빌", "bes870", "coffee", "커피", "espresso"], "11"],
    [["cuckoo", "쿠쿠", "crplhtr", "밥솥", "ricecooker"], "12"],
    [["제트봇", "jetbot", "vr50"], "13"],
    [["오브제", "dub22", "식기세척기", "dishwasher"], "14"],
    [["tefal", "테팔", "ih201", "인덕션", "induction"], "15"],
    [["winix", "위닉스", "dn2h", "제습기", "dehumidifier"], "16"],
    [["electrolux", "일렉트로룩스", "ep71"], "17"],
    [["braun", "브라운", "series9", "면도기", "shaver"], "18"],
    [["쿠잉", "nje3570", "착즙기", "juicer"], "19"],
    [["vitamix", "비타믹스", "a3500", "blender", "블렌더"], "20"],
    [["samsung", "삼성"], "10"],
    [["lg"], "1"],
    [["xiaomi", "샤오미", "미에어"], "5"],
    [["공기청정기", "airpurifier", "purifier"], "1"],
    [["냉장고", "fridge", "refrigerator"], "4"],
    [["robot", "로봇", "robovac", "청소기", "vacuum"], "2"],
    [["hair", "헤어", "스타일러", "styler"], "3"],
  ];

  for (const [keywords, id] of rules) {
    if (keywords.some((kw) => s.includes(kw))) return id;
  }
  return null;
}

// base64 데이터 → 결정론적 해시 (최종 폴백)
function computeImageHash(base64: string): number {
  let hash = 5381;
  const step = Math.max(1, Math.floor(base64.length / 300));
  for (let i = 0; i < base64.length; i += step) {
    hash = ((hash << 5) + hash + base64.charCodeAt(i)) | 0;
  }
  return Math.abs(hash);
}

/**
 * 인식 우선순위:
 *  1) Claude vision API (API 키가 있을 때)
 *  2) 파일명 키워드
 *  3) 결정론적 해시 폴백
 */
async function recognizeProduct(
  file: File,
  base64: string
): Promise<{ id: string; confidence: number; method: "claude" | "filename" | "hash" }> {
  // 1) Gemini vision
  try {
    const vision = await analyzeWithGeminiVision(base64);
    if (vision) return { ...vision, method: "claude" };
  } catch (err) {
    console.error("[Gemini Vision] 오류:", err);
  }

  // 2) 파일명 키워드
  const fromName = recognizeFromFilename(file.name);
  if (fromName) return { id: fromName, confidence: 97 + Math.random() * 2.5, method: "filename" };

  // 3) 해시 폴백
  const hash = computeImageHash(base64);
  const id = String((hash % products.length) + 1);
  return { id, confidence: 78 + Math.random() * 10, method: "hash" };
}

const scanSteps = [
  { icon: Brain, text: "Gemini 비전 AI 이미지 분석 중..." },
  { icon: ScanLine, text: "제품 형태·브랜드 로고 인식 중..." },
  { icon: Cpu, text: "모델명·시리얼 특징 추출 중..." },
  { icon: Database, text: "카탈로그 매칭 완료 중..." },
];

export function Camera() {
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const pendingRecognition = useRef<{ id: string; confidence: number; method: "claude" | "filename" | "hash" } | null>(null);


  const [mode, setMode] = useState<AnalysisMode>("image");
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [scanStepIndex, setScanStepIndex] = useState(0);
  const [url, setUrl] = useState("");
  const [identifiedProduct, setIdentifiedProduct] = useState<Product | null>(null);
  const [confidence, setConfidence] = useState(0);
  const [recognitionMethod, setRecognitionMethod] = useState<"claude" | "filename" | "hash" | null>(null);

  useEffect(() => {
    if (!isScanning) return;

    const interval = setInterval(() => {
      setScanProgress((prev) => {
        const next = prev + 2;

        // 단계 업데이트
        if (next >= 25 && next < 55) setScanStepIndex(1);
        else if (next >= 55 && next < 80) setScanStepIndex(2);
        else if (next >= 80) setScanStepIndex(3);

        if (next >= 100) {
          // 이미지 특징 분석이 아직 끝나지 않았으면 99%에서 잠시 대기
          if (!pendingRecognition.current) return 99;

          clearInterval(interval);
          setIsScanning(false);

          const result = pendingRecognition.current;
          if (result) {
            const product = getProductById(result.id);
            if (product) {
              setIdentifiedProduct(product);
              setConfidence(result.confidence);
              setRecognitionMethod(result.method);
              const label = result.method === "claude" ? "Claude AI" : result.method === "filename" ? "파일명" : "해시";
              toast.success(`${product.name} 인식 완료 (${label})`, {
                icon: <Sparkles className="w-4 h-4 text-[#B5DEFF]" />,
                duration: 2000,
              });
            }
          }
          return 100;
        }
        return next;
      });
    }, 40);

    return () => clearInterval(interval);
  }, [isScanning]);

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (e) => {
      const base64 = e.target?.result as string;
      setSelectedImage(base64);
      setIsScanning(true);
      setScanProgress(0);
      setScanStepIndex(0);
      // 실제 이미지 특징 분석은 비동기 → 스캔 애니메이션이 도는 동안 계산
      pendingRecognition.current = null;
      pendingRecognition.current = await recognizeProduct(file, base64);
    };
    reader.readAsDataURL(file);
  };

  const handleAnalyze = () => {
    if (mode === "link" && !url.trim()) {
      toast.error("분석할 상품 URL을 입력해주세요.");
      return;
    }
    const productId = mode === "image" && identifiedProduct
      ? identifiedProduct.id
      : String((computeImageHash(Date.now().toString()) % products.length) + 1);
    localStorage.setItem("currentProductId", productId);
    navigate("/loading");
  };

  const handleReset = () => {
    setSelectedImage(null);
    setIsScanning(false);
    setScanProgress(0);
    setScanStepIndex(0);
    setUrl("");
    setIdentifiedProduct(null);
    setConfidence(0);
    setRecognitionMethod(null);
    pendingRecognition.current = null;
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const currentStep = scanSteps[scanStepIndex];

  return (
    <div className="h-full bg-slate-50 flex flex-col w-full overflow-hidden">
      {/* Header */}
      <div className="bg-white px-4 pt-4 pb-2 flex items-center justify-between border-b shrink-0">
        <div>
          <h2 className="font-bold text-sm text-gray-900 tracking-tight">스마트 분석 센터</h2>
          <p className="text-[9px] text-[#B5DEFF] font-bold uppercase tracking-widest">AI Smart Analysis Hub</p>
        </div>
        <button onClick={() => navigate("/home")} className="p-1.5 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
          <X className="w-4 h-4 text-gray-500" />
        </button>
      </div>

      {/* Mode Selector */}
      <div className="bg-white px-3 py-2 flex gap-2 shrink-0">
        <button
          onClick={() => setMode("image")}
          className={`flex-1 py-2 rounded-xl text-[11px] font-bold transition-all flex items-center justify-center gap-1.5 ${
            mode === "image"
              ? "bg-[#B5DEFF] text-white shadow-lg shadow-[#B5DEFF]/20"
              : "bg-gray-50 text-gray-400 border border-gray-100"
          }`}
        >
          <CameraIcon className="w-3.5 h-3.5" />
          이미지 분석
        </button>
        <button
          onClick={() => setMode("link")}
          className={`flex-1 py-2 rounded-xl text-[11px] font-bold transition-all flex items-center justify-center gap-1.5 ${
            mode === "link"
              ? "bg-[#B5DEFF] text-white shadow-lg shadow-[#B5DEFF]/20"
              : "bg-gray-50 text-gray-400 border border-gray-100"
          }`}
        >
          <LinkIcon className="w-3.5 h-3.5" />
          링크/추적
        </button>
      </div>

      {/* Main Content */}
      <div className="flex-1 min-h-0 p-3 flex flex-col overflow-hidden">
        <AnimatePresence mode="wait">
          {mode === "image" ? (
            <motion.div
              key="image-mode"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="flex-1 flex flex-col"
            >
              {!selectedImage ? (
                <div className="flex-1 flex flex-col">
                  {/* Camera Hub */}
                  <div
                    onClick={() => fileInputRef.current?.click()}
                    className="relative flex-1 min-h-0 bg-gradient-to-br from-[#E8F4FF] via-[#F1F7FF] to-[#F8FAFC] rounded-[28px] mb-2.5 overflow-hidden flex flex-col items-center justify-center cursor-pointer group shadow-md shadow-slate-200/60 border border-slate-100"
                  >
                    <div className="absolute -top-10 -right-10 w-40 h-40 bg-[#B5DEFF]/15 rounded-full blur-3xl" />
                    <div className="relative z-10 flex flex-col items-center">
                      <div className="w-14 h-14 bg-[#B5DEFF] rounded-[20px] flex items-center justify-center mb-3 group-hover:scale-110 group-hover:rotate-3 transition-all duration-500 shadow-md shadow-[#B5DEFF]/30 border-2 border-white">
                        <CameraIcon className="w-7 h-7 text-white" />
                      </div>
                      <div className="text-center px-6">
                        <h3 className="font-black text-slate-800 mb-1 text-sm tracking-tight">AI 렌즈 활성화</h3>
                        <p className="text-[10px] text-slate-500 leading-snug font-bold">
                          제품을 비추거나<br />앨범에서 사진을 선택하세요
                        </p>
                      </div>
                    </div>
                    <div className="absolute inset-0 pointer-events-none opacity-50">
                      <motion.div
                        animate={{ top: ["0%", "100%", "0%"] }}
                        transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                        className="absolute left-0 right-0 h-px bg-[#B5DEFF] shadow-[0_0_20px_2px_rgba(181,222,255,0.8)]"
                      />
                    </div>
                    <div className="absolute top-5 left-5 w-6 h-6 border-l-2 border-t-2 border-[#B5DEFF] rounded-tl-xl opacity-60 group-hover:opacity-100 group-hover:scale-110 transition-all duration-500" />
                    <div className="absolute top-5 right-5 w-6 h-6 border-r-2 border-t-2 border-[#B5DEFF] rounded-tr-xl opacity-60 group-hover:opacity-100 group-hover:scale-110 transition-all duration-500" />
                    <div className="absolute bottom-5 left-5 w-6 h-6 border-l-2 border-b-2 border-[#B5DEFF] rounded-bl-xl opacity-60 group-hover:opacity-100 group-hover:scale-110 transition-all duration-500" />
                    <div className="absolute bottom-5 right-5 w-6 h-6 border-r-2 border-b-2 border-[#B5DEFF] rounded-br-xl opacity-60 group-hover:opacity-100 group-hover:scale-110 transition-all duration-500" />
                  </div>

                  <div className="bg-white rounded-[18px] px-3 py-2 shadow-md shadow-slate-200/60 border border-slate-50 flex items-center gap-2.5 mb-2.5 shrink-0">
                    <div className="w-8 h-8 bg-amber-50 rounded-xl flex items-center justify-center shrink-0 border border-amber-100/50">
                      <Sparkles className="w-4 h-4 text-amber-500 animate-pulse" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-black text-slate-900 text-[11px] uppercase tracking-tight">AI Smart Vision</h4>
                      <p className="text-[9px] font-bold text-slate-400 leading-tight">
                        모델명을 선명하게 비출수록 정확도가 상승합니다 (평균 99.8%)
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 shrink-0">
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      className="bg-white text-slate-900 h-11 rounded-[18px] font-black border-2 border-slate-50 flex items-center justify-center gap-1.5 shadow-lg shadow-slate-200 active:scale-95 transition-all uppercase text-[10px] tracking-widest"
                    >
                      <Upload className="w-4 h-4 text-[#B5DEFF]" />
                      Gallery
                    </button>
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      className="bg-[#B5DEFF] text-white h-11 rounded-[18px] font-black flex items-center justify-center gap-1.5 shadow-xl shadow-[#B5DEFF]/40 active:scale-95 transition-all uppercase text-[10px] tracking-widest border-t-2 border-white/20"
                    >
                      <CameraIcon className="w-4 h-4" />
                      Take Photo
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex-1 flex flex-col gap-3">
                  {/* Image Preview */}
                  <div className="relative flex-1 min-h-0 bg-white rounded-[28px] overflow-hidden shadow-2xl border-4 border-white">
                    <img
                      src={selectedImage}
                      alt="Selected product"
                      className={`w-full h-full object-cover transition-all duration-700 ${
                        isScanning ? "grayscale-[0.4] brightness-75" : "grayscale-0 brightness-100"
                      }`}
                    />

                    {/* Scan line */}
                    {isScanning && (
                      <motion.div
                        initial={{ top: "-5%" }}
                        animate={{ top: "105%" }}
                        transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                        className="absolute left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-[#B5DEFF] to-transparent shadow-[0_0_20px_4px_rgba(181,222,255,0.9)] z-30 pointer-events-none"
                      />
                    )}

                    {/* Recognition points */}
                    {isScanning && (
                      <div className="absolute inset-0 z-20 overflow-hidden pointer-events-none">
                        {[0, 1, 2, 3, 4].map((i) => (
                          <motion.div
                            key={i}
                            initial={{ scale: 0, opacity: 0 }}
                            animate={{ scale: [0, 1.3, 0], opacity: [0, 0.9, 0] }}
                            transition={{ duration: 2.5, repeat: Infinity, delay: i * 0.6, ease: "easeInOut" }}
                            style={{ left: `${18 + i * 14}%`, top: `${25 + i * 11}%` }}
                            className="absolute w-3.5 h-3.5 rounded-full border-2 border-[#B5DEFF] bg-[#B5DEFF]/30"
                          />
                        ))}
                      </div>
                    )}

                    {/* Scan overlay */}
                    {isScanning && (
                      <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-[1px] flex flex-col items-center justify-center z-10">
                        <div className="bg-white/96 backdrop-blur-xl px-6 py-5 rounded-[28px] shadow-2xl flex flex-col items-center gap-3 w-[75%] text-center border border-white/50">
                          <div className="relative w-14 h-14">
                            <div className="absolute inset-0 rounded-full border-4 border-[#B5DEFF]/20" />
                            <div className="absolute inset-0 rounded-full border-4 border-[#B5DEFF] border-t-transparent animate-spin" />
                            <div className="absolute inset-0 flex items-center justify-center">
                              <currentStep.icon className="w-5 h-5 text-[#B5DEFF]" />
                            </div>
                          </div>

                          <div>
                            <p className="font-black text-gray-900 text-base leading-tight mb-0.5">AI 정밀 분석 중</p>
                            <AnimatePresence mode="wait">
                              <motion.p
                                key={scanStepIndex}
                                initial={{ opacity: 0, y: 4 }}
                                animate={{ opacity: 1, y: 0 }}
                                exit={{ opacity: 0, y: -4 }}
                                className="text-[10px] font-bold text-[#B5DEFF] tracking-wide"
                              >
                                {currentStep.text}
                              </motion.p>
                            </AnimatePresence>
                          </div>

                          <div className="w-full">
                            <div className="flex justify-between mb-1">
                              <span className="text-[9px] font-bold text-gray-400 uppercase tracking-widest">Progress</span>
                              <span className="text-[9px] font-bold text-[#B5DEFF]">{scanProgress}%</span>
                            </div>
                            <div className="w-full h-1.5 bg-gray-100 rounded-full overflow-hidden">
                              <motion.div
                                animate={{ width: `${scanProgress}%` }}
                                transition={{ ease: "linear" }}
                                className="h-full bg-gradient-to-r from-[#B5DEFF] to-[#7EC8F5] rounded-full"
                              />
                            </div>
                          </div>

                          {/* Step dots */}
                          <div className="flex gap-1.5">
                            {scanSteps.map((_, i) => (
                              <div
                                key={i}
                                className={`h-1 rounded-full transition-all duration-500 ${
                                  i <= scanStepIndex ? "bg-[#B5DEFF] w-4" : "bg-gray-200 w-1.5"
                                }`}
                              />
                            ))}
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Result card */}
                    <AnimatePresence>
                      {!isScanning && identifiedProduct && (
                        <motion.div
                          initial={{ opacity: 0, y: 30, scale: 0.92 }}
                          animate={{ opacity: 1, y: 0, scale: 1 }}
                          transition={{ type: "spring", damping: 20 }}
                          className="absolute bottom-4 left-4 right-4 bg-white/96 backdrop-blur-xl rounded-[24px] p-4 shadow-2xl border border-white/60 z-40"
                        >
                          <div className="flex items-center gap-3">
                            <div className="w-16 h-16 bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden shrink-0 relative">
                              <img src={identifiedProduct.image} alt={identifiedProduct.name} className="w-full h-full object-cover" />
                              <div className="absolute inset-0 bg-green-500/10 flex items-center justify-center">
                                <CheckCircle2 className="w-7 h-7 text-green-500 bg-white rounded-full p-1 shadow-md" />
                              </div>
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-1.5 mb-1 flex-wrap">
                                <div className="bg-[#B5DEFF]/10 px-2 py-0.5 rounded-lg flex items-center gap-1">
                                  <Tag className="w-3 h-3 text-[#B5DEFF]" />
                                  <span className="text-[10px] font-black text-[#B5DEFF] uppercase tracking-wide">{identifiedProduct.model}</span>
                                </div>
                                <span className="text-[10px] font-bold text-green-600 bg-green-50 px-2 py-0.5 rounded-lg">
                                  {confidence.toFixed(1)}%
                                </span>
                                {recognitionMethod === "claude" && (
                                  <span className="text-[9px] font-black text-purple-600 bg-purple-50 px-2 py-0.5 rounded-lg flex items-center gap-0.5">
                                    <Brain className="w-2.5 h-2.5" />
                                    Gemini AI
                                  </span>
                                )}
                              </div>
                              <p className="text-sm font-black text-gray-900 leading-snug line-clamp-2">{identifiedProduct.name}</p>
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>

                    <button
                      onClick={handleReset}
                      className="absolute top-4 right-4 w-10 h-10 bg-white/90 backdrop-blur-md rounded-xl flex items-center justify-center text-gray-500 shadow-lg z-50 active:scale-90 transition-all"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  {/* Action buttons */}
                  <div className="flex flex-col gap-2 shrink-0">
                    <button
                      onClick={handleAnalyze}
                      disabled={isScanning}
                      className="w-full bg-[#B5DEFF] text-white h-14 rounded-[22px] font-bold shadow-lg shadow-[#B5DEFF]/30 flex items-center justify-center gap-2 active:scale-[0.98] transition-all disabled:opacity-50 text-sm"
                    >
                      {isScanning ? "인공지능 분석 중..." : "실시간 최저가 분석하기"}
                    </button>
                    <button
                      onClick={handleReset}
                      disabled={isScanning}
                      className="w-full bg-white text-gray-400 h-11 rounded-[18px] font-bold flex items-center justify-center gap-2 active:scale-[0.98] transition-all disabled:opacity-50 text-xs"
                    >
                      다시 선택하기
                    </button>
                  </div>
                </div>
              )}
            </motion.div>
          ) : (
            <motion.div
              key="link-mode"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="flex-1 flex flex-col"
            >
              <div className="bg-white rounded-[24px] p-4 shadow-sm border border-gray-100 flex flex-col items-center text-center shrink-0">
                <div className="w-14 h-14 bg-[#B5DEFF]/10 rounded-[18px] flex items-center justify-center mb-2">
                  <LinkIcon className="w-6 h-6 text-[#B5DEFF]" />
                </div>
                <h3 className="font-bold text-sm text-gray-800 mb-1">쇼핑몰 링크 분석</h3>
                <p className="text-[10px] text-gray-400 mb-3 leading-snug">
                  쿠팡, 네이버, 11번가 등의 상품 링크를 붙여넣어 주세요
                </p>
                <div className="w-full space-y-2">
                  <div className="relative group">
                    <div className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-[#B5DEFF] transition-colors">
                      <LinkIcon className="w-4 h-4" />
                    </div>
                    <input
                      type="text"
                      value={url}
                      onChange={(e) => setUrl(e.target.value)}
                      placeholder="상품 URL 또는 링크를 입력하세요"
                      className="w-full pl-10 pr-3 py-2.5 bg-gray-50 rounded-[14px] border-2 border-transparent focus:border-[#B5DEFF]/30 focus:bg-white transition-all outline-none text-xs font-medium"
                    />
                  </div>
                  <div className="bg-blue-50/50 rounded-xl p-2.5 flex items-start gap-2 text-left">
                    <AlertCircle className="w-3.5 h-3.5 text-[#B5DEFF] mt-0.5 shrink-0" />
                    <p className="text-[10px] text-gray-500 leading-snug">
                      링크를 입력하면 실시간 가격 변동을 수집하고 최저가 알림을 설정해 드립니다.
                    </p>
                  </div>
                </div>
                <button
                  onClick={handleAnalyze}
                  className="w-full mt-3 bg-[#B5DEFF] text-white h-11 rounded-[18px] font-bold shadow-lg shadow-[#B5DEFF]/30 flex items-center justify-center gap-2 active:scale-[0.98] transition-all text-xs"
                >
                  <Sparkles className="w-4 h-4" />
                  실시간 가격 분석 시작
                </button>
              </div>

              <div className="mt-2.5 shrink-0">
                <h4 className="font-bold text-gray-800 text-[11px] mb-1.5 px-1">최근 복사한 링크 인식</h4>
                <div
                  onClick={() => setUrl("https://www.coupang.com/vp/products/...")}
                  className="bg-white p-2.5 rounded-2xl border border-gray-100 flex items-center gap-2.5 cursor-pointer hover:bg-gray-50 active:scale-95 transition-all shadow-sm"
                >
                  <div className="w-8 h-8 bg-gray-50 rounded-xl flex items-center justify-center shrink-0">
                    <LinkIcon className="w-4 h-4 text-gray-300" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-[9px] font-bold text-gray-400 uppercase tracking-tighter">COUPANG.COM</p>
                    <p className="text-[11px] font-bold text-gray-700 truncate">https://www.coupang.com/vp/products/7654...</p>
                  </div>
                  <div className="text-[#B5DEFF] font-bold text-[9px] bg-[#B5DEFF]/10 px-1.5 py-0.5 rounded-md shrink-0">자동완성</div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        onChange={handleFileSelect}
        className="hidden"
      />
    </div>
  );
}
