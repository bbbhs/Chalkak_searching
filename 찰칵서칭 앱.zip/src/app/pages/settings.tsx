import { Bell, HelpCircle, Shield, Info, ChevronRight, Trash2, User, LogOut, Settings as SettingsIcon, MessageSquare, CreditCard, Share2, Star, Smartphone, Lock } from "lucide-react";
import { Card } from "../components/ui/card";
import { Switch } from "../components/ui/switch";
import { useState } from "react";
import { Logo } from "../components/logo";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "../components/ui/alert-dialog";
import { toast } from "sonner";

import { useNavigate } from "react-router";
import { useUserStore } from "../store/user-store";

export function Settings() {
  const navigate = useNavigate();
  const { profile } = useUserStore();
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [priceDropAlerts, setPriceDropAlerts] = useState(true);
  const [marketingAlerts, setMarketingAlerts] = useState(false);
  const [logoutOpen, setLogoutOpen] = useState(false);

  const handleLogout = () => {
    setLogoutOpen(false);
    toast.success("로그아웃 되었습니다.", {
      icon: <LogOut className="w-4 h-4 text-red-500" />,
    });
    setTimeout(() => navigate("/"), 400);
  };

  const profileImageUrl = "https://images.unsplash.com/photo-1635353692890-80a6b95add47?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxrb3JlYW4lMjBwZXJzb24lMjBwcm9maWxlJTIwcGhvdG98ZW58MXx8fHwxNzc2MjM1MDA2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral";

  return (
    <div className="h-full overflow-auto bg-slate-50 pb-14">
      {/* Header */}
      <div className="bg-white px-4 pt-6 pb-3 border-b">
        <div className="flex items-center justify-between mb-3">
          <Logo size={22} />
          <button className="p-1.5 hover:bg-gray-100 rounded-lg transition-colors">
            <SettingsIcon className="w-4 h-4 text-gray-500" />
          </button>
        </div>
        <h1 className="text-lg font-bold text-gray-900">설정</h1>
      </div>

      <div className="px-4 py-3 space-y-3">
        {/* Profile Section */}
        <Card className="p-3 border-none shadow-sm bg-white overflow-hidden relative">
          <div className="absolute top-0 right-0 w-20 h-20 bg-[#B5DEFF]/10 rounded-full -mr-10 -mt-10" />
          <div className="flex items-center gap-2.5 relative z-10">
            <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-[#B5DEFF]/20 shadow-sm shrink-0">
              <ImageWithFallback
                src={profile.profileImage}
                alt="Profile"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex-1 min-w-0">
              <h2 className="text-sm font-bold text-gray-900 truncate">{profile.name} 님</h2>
              <p className="text-[11px] text-gray-500 truncate">{profile.email}</p>
              <div className="mt-0.5 inline-flex items-center px-1.5 py-0.5 rounded text-[8px] font-medium bg-[#B5DEFF]/10 text-[#B5DEFF]">
                프리미엄 회원
              </div>
            </div>
            <button
              onClick={() => navigate("/settings/profile")}
              className="p-1 hover:bg-gray-100 rounded-md transition-colors group"
            >
              <ChevronRight className="w-3.5 h-3.5 text-gray-400 group-hover:text-gray-600" />
            </button>
          </div>
        </Card>

        {/* Account & Security Section */}
        <section className="space-y-2 pt-2">
          <h3 className="px-1 text-[11px] font-semibold text-gray-400 uppercase tracking-wider">계정 및 보안</h3>
          <Card className="border-none shadow-sm bg-white overflow-hidden">
            <div className="divide-y">
              <button className="w-full px-3 py-2 flex items-center justify-between hover:bg-gray-50 transition-colors">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 bg-indigo-50 rounded-md flex items-center justify-center">
                    <Lock className="w-3.5 h-3.5 text-indigo-500" />
                  </div>
                  <span className="font-medium text-xs text-gray-700">비밀번호 변경</span>
                </div>
                <ChevronRight className="w-3.5 h-3.5 text-gray-300" />
              </button>
              <button className="w-full px-3 py-2 flex items-center justify-between hover:bg-gray-50 transition-colors">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 bg-orange-50 rounded-md flex items-center justify-center">
                    <CreditCard className="w-3.5 h-3.5 text-orange-500" />
                  </div>
                  <span className="font-medium text-xs text-gray-700">결제 수단 관리</span>
                </div>
                <ChevronRight className="w-3.5 h-3.5 text-gray-300" />
              </button>
            </div>
          </Card>
        </section>

        {/* Section: 알림 및 서비스 */}
        <section className="space-y-2">
          <h3 className="px-1 text-[11px] font-semibold text-gray-400 uppercase tracking-wider">알림 설정</h3>
          <Card className="border-none shadow-sm bg-white overflow-hidden">
            <div className="divide-y">
              <div className="px-3 py-2 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 bg-rose-50 rounded-md flex items-center justify-center">
                    <Bell className="w-3.5 h-3.5 text-rose-500" />
                  </div>
                  <div>
                    <p className="font-medium text-xs text-gray-700">푸시 알림 허용</p>
                    <p className="text-[9px] text-gray-400">최신 가격 변동</p>
                  </div>
                </div>
                <Switch checked={notificationsEnabled} onCheckedChange={setNotificationsEnabled} />
              </div>
              <div className="px-3 py-2 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 bg-emerald-50 rounded-md flex items-center justify-center">
                    <Star className="w-3.5 h-3.5 text-emerald-500" />
                  </div>
                  <div>
                    <p className="font-medium text-xs text-gray-700">최저가 하락 알림</p>
                    <p className="text-[9px] text-gray-400">목표가 도달 시</p>
                  </div>
                </div>
                <Switch checked={priceDropAlerts} onCheckedChange={setPriceDropAlerts} disabled={!notificationsEnabled} />
              </div>
              <div className="px-3 py-2 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 bg-amber-50 rounded-md flex items-center justify-center">
                    <Smartphone className="w-3.5 h-3.5 text-amber-500" />
                  </div>
                  <div>
                    <p className="font-medium text-xs text-gray-700">마케팅 정보 수신</p>
                    <p className="text-[9px] text-gray-400">이벤트 안내</p>
                  </div>
                </div>
                <Switch checked={marketingAlerts} onCheckedChange={setMarketingAlerts} disabled={!notificationsEnabled} />
              </div>
            </div>
          </Card>
        </section>

        {/* Section: 고객지원 */}
        <section className="space-y-2">
          <h3 className="px-1 text-[11px] font-semibold text-gray-400 uppercase tracking-wider">고객지원</h3>
          <Card className="border-none shadow-sm bg-white overflow-hidden">
            <div className="divide-y">
              <button className="w-full px-3 py-2 flex items-center justify-between hover:bg-gray-50 transition-colors">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 bg-blue-50 rounded-md flex items-center justify-center">
                    <HelpCircle className="w-3.5 h-3.5 text-blue-500" />
                  </div>
                  <span className="font-medium text-xs text-gray-700">FAQ</span>
                </div>
                <ChevronRight className="w-3.5 h-3.5 text-gray-300" />
              </button>
              <button className="w-full px-3 py-2 flex items-center justify-between hover:bg-gray-50 transition-colors">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 bg-violet-50 rounded-md flex items-center justify-center">
                    <MessageSquare className="w-3.5 h-3.5 text-violet-500" />
                  </div>
                  <span className="font-medium text-xs text-gray-700">1:1 문의</span>
                </div>
                <ChevronRight className="w-3.5 h-3.5 text-gray-300" />
              </button>
              <button className="w-full px-3 py-2 flex items-center justify-between hover:bg-gray-50 transition-colors">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 bg-pink-50 rounded-md flex items-center justify-center">
                    <Share2 className="w-3.5 h-3.5 text-pink-500" />
                  </div>
                  <span className="font-medium text-xs text-gray-700">친구 추천</span>
                </div>
                <ChevronRight className="w-3.5 h-3.5 text-gray-300" />
              </button>
            </div>
          </Card>
        </section>

        {/* Section: 데이터 및 기타 */}
        <section className="space-y-2">
          <h3 className="px-1 text-[11px] font-semibold text-gray-400 uppercase tracking-wider">기타</h3>
          <Card className="border-none shadow-sm bg-white overflow-hidden">
            <div className="divide-y">
              <button className="w-full px-3 py-2 flex items-center justify-between hover:bg-gray-50 transition-colors">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 bg-gray-50 rounded-md flex items-center justify-center">
                    <Trash2 className="w-3.5 h-3.5 text-gray-500" />
                  </div>
                  <span className="font-medium text-xs text-gray-700">기록 초기화</span>
                </div>
                <ChevronRight className="w-3.5 h-3.5 text-gray-300" />
              </button>
              <AlertDialog open={logoutOpen} onOpenChange={setLogoutOpen}>
                <AlertDialogTrigger asChild>
                  <button className="w-full px-3 py-2 flex items-center justify-between hover:bg-gray-50 transition-colors text-red-500">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 bg-red-50 rounded-md flex items-center justify-center">
                        <LogOut className="w-3.5 h-3.5 text-red-500" />
                      </div>
                      <span className="font-medium text-xs">로그아웃</span>
                    </div>
                  </button>
                </AlertDialogTrigger>
                <AlertDialogContent className="w-[260px] max-w-[260px] rounded-2xl p-4 gap-2 top-[426px]">
                  <AlertDialogHeader className="items-center text-center space-y-1.5">
                    <div className="w-9 h-9 bg-red-50 rounded-full flex items-center justify-center">
                      <LogOut className="w-4 h-4 text-red-500" />
                    </div>
                    <AlertDialogTitle className="text-sm font-bold text-gray-900">
                      로그아웃 하시겠어요?
                    </AlertDialogTitle>
                    <AlertDialogDescription className="text-[11px] text-gray-500 leading-snug">
                      찜한 상품과 분석 기록은<br />다시 로그인하면 그대로 보실 수 있어요.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter className="flex-row gap-1.5 mt-1">
                    <AlertDialogCancel className="flex-1 mt-0 rounded-lg h-8 text-[11px] font-bold border-gray-200">
                      취소
                    </AlertDialogCancel>
                    <AlertDialogAction
                      onClick={handleLogout}
                      className="flex-1 rounded-lg h-8 text-[11px] font-bold bg-red-500 hover:bg-red-600"
                    >
                      로그아웃
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          </Card>
        </section>

        {/* Branding Footer */}
        <div className="text-center pt-4 pb-6">
          <div className="opacity-60 grayscale hover:grayscale-0 transition-all mx-auto mb-1.5 w-fit">
            <Logo size={20} />
          </div>
          <div className="flex items-center justify-center gap-2 mb-1.5">
            <button className="text-[10px] text-gray-400 hover:text-gray-600 transition-colors underline underline-offset-2">개인정보</button>
            <div className="w-0.5 h-0.5 bg-gray-300 rounded-full" />
            <button className="text-[10px] text-gray-400 hover:text-gray-600 transition-colors underline underline-offset-2">이용약관</button>
          </div>
          <p className="text-[10px] text-gray-400">버전 1.2.4</p>
          <p className="text-[8px] text-gray-300 mt-1">© 2024 CLICK SEARCHING</p>
        </div>
      </div>
    </div>
  );
}