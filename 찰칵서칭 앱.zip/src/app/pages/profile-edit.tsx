import { useState } from "react";
import { useNavigate } from "react-router";
import { ChevronLeft, Camera, User, Mail, Phone, Check } from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import { toast } from "sonner";
import { useUserStore } from "../store/user-store";

export function ProfileEdit() {
  const navigate = useNavigate();
  const { profile, updateProfile } = useUserStore();
  const [name, setName] = useState(profile.name);
  const [email, setEmail] = useState(profile.email);
  const [phone, setPhone] = useState(profile.phone);
  const [profileImage, setProfileImage] = useState(profile.profileImage);
  const [isSaving, setIsSaving] = useState(false);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfileImage(reader.result as string);
        toast.info("사진이 선택되었습니다. 저장 버튼을 눌러주세요.");
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = () => {
    setIsSaving(true);
    // Simulate API call
    setTimeout(() => {
      updateProfile({ name, email, phone, profileImage });
      setIsSaving(false);
      toast.success("프로필 정보가 수정되었습니다.");
      navigate("/settings");
    }, 800);
  };

  return (
    <div className="h-full bg-slate-50 flex flex-col overflow-hidden">
      {/* Header */}
      <div className="bg-white px-5 pt-4 pb-2 flex items-center justify-between border-b shrink-0">
        <button
          onClick={() => navigate(-1)}
          className="w-9 h-9 flex items-center justify-center hover:bg-gray-100 rounded-full transition-colors"
        >
          <ChevronLeft className="w-5 h-5 text-gray-700" />
        </button>
        <h1 className="font-bold text-base text-gray-900">프로필 수정</h1>
        <div className="w-9 h-9" aria-hidden />
      </div>

      <div className="flex-1 min-h-0 px-5 pt-4 flex flex-col gap-4 overflow-hidden">
        {/* Profile Image Section */}
        <div className="flex flex-col items-center shrink-0">
          <div className="relative">
            <div className="w-20 h-20 rounded-full overflow-hidden border-4 border-white shadow-md">
              <ImageWithFallback
                src={profileImage}
                alt="Profile"
                className="w-full h-full object-cover"
              />
            </div>
            <label className="absolute bottom-0 right-0 w-7 h-7 bg-[#B5DEFF] text-white rounded-full flex items-center justify-center border-2 border-white shadow-sm hover:bg-[#8FC8F0] transition-colors cursor-pointer">
              <Camera className="w-3.5 h-3.5" />
              <input
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleImageChange}
              />
            </label>
          </div>
          <p className="mt-2 text-xs font-medium text-[#B5DEFF]">프로필 사진 변경</p>
        </div>

        {/* Form Fields */}
        <div className="space-y-3">
          <div className="space-y-1">
            <label className="text-[11px] font-semibold text-gray-400 ml-1">이름</label>
            <div className="relative">
              <div className="absolute left-3.5 top-1/2 -translate-y-1/2">
                <User className="w-4 h-4 text-gray-300" />
              </div>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full pl-10 pr-3 py-3 bg-white border-none rounded-xl shadow-sm focus:ring-2 focus:ring-[#B5DEFF]/30 transition-all outline-none text-gray-700 font-medium text-sm"
                placeholder="이름을 입력하세요"
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-[11px] font-semibold text-gray-400 ml-1">이메일</label>
            <div className="relative">
              <div className="absolute left-3.5 top-1/2 -translate-y-1/2">
                <Mail className="w-4 h-4 text-gray-300" />
              </div>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-10 pr-3 py-3 bg-white border-none rounded-xl shadow-sm focus:ring-2 focus:ring-[#B5DEFF]/30 transition-all outline-none text-gray-700 font-medium text-sm"
                placeholder="이메일을 입력하세요"
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-[11px] font-semibold text-gray-400 ml-1">휴대폰 번호</label>
            <div className="relative">
              <div className="absolute left-3.5 top-1/2 -translate-y-1/2">
                <Phone className="w-4 h-4 text-gray-300" />
              </div>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full pl-10 pr-3 py-3 bg-white border-none rounded-xl shadow-sm focus:ring-2 focus:ring-[#B5DEFF]/30 transition-all outline-none text-gray-700 font-medium text-sm"
                placeholder="010-0000-0000"
              />
            </div>
          </div>
        </div>

        {/* Save Button */}
        <div className="mt-auto pb-3">
          <button
            onClick={handleSave}
            disabled={isSaving}
            className={`w-full py-3 rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-md active:scale-[0.98] text-sm ${
              isSaving ? "bg-gray-200 text-gray-400" : "bg-[#B5DEFF] text-white hover:bg-[#8FC8F0]"
            }`}
          >
            {isSaving ? (
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <>
                <Check className="w-4 h-4" />
                저장하기
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}