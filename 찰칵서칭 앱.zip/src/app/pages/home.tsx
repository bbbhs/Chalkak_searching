import { useNavigate } from "react-router";
import { Camera, Upload, TrendingDown, TrendingUp, Minus, Link as LinkIcon, Search, Plus, Sparkles } from "lucide-react";
import { useState, useMemo } from "react";
import { Card } from "../components/ui/card";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import { products } from "../data/products";
import { toast } from "sonner";
import { useSearchStore } from "../store/useSearchStore";
import { Logo } from "../components/logo";
import { formatDistanceToNow } from 'date-fns';
import { ko } from 'date-fns/locale';

const getPriceStatusInfo = (status: string, current: number, prev: number) => {
  const diff = current - prev;
  const isDown = diff < 0;
  
  switch (status) {
    case "low":
      return {
        label: "역대 최저가",
        color: "text-green-600",
        bgColor: "bg-green-50",
        icon: TrendingDown,
        desc: isDown ? `${Math.abs(diff).toLocaleString()}원 하락` : "최저가 유지중",
      };
    case "high":
      return {
        label: "가격 상승",
        color: "text-red-600",
        bgColor: "bg-red-50",
        icon: TrendingUp,
        desc: `${Math.abs(diff).toLocaleString()}원 상승`,
      };
    default:
      return {
        label: "평균가 유지",
        color: "text-gray-600",
        bgColor: "bg-gray-50",
        icon: Minus,
        desc: "변동폭 적음",
      };
  }
};

export function Home() {
  const navigate = useNavigate();
  const [url, setUrl] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  
  // Zustand 스토어에서 히스토리 가져오기
  const history = useSearchStore((state) => state.history);
  const clearHistory = useSearchStore((state) => state.clearHistory);

  const handleUrlAnalysis = () => {
    if (!url.trim()) {
      toast.error("상품 URL을 입력해주세요.");
      return;
    }
    
    setIsAnalyzing(true);
    // 실제 검색 로직 시뮬레이션
    setTimeout(() => {
      setIsAnalyzing(false);
      setUrl("");
      // 임의의 제품 ID 선택하여 분석 페이지로 이동 (분석 후 스토어에 저장됨)
      const randomProduct = products[Math.floor(Math.random() * products.length)];
      localStorage.setItem("currentProductId", randomProduct.id);
      navigate("/loading");
    }, 1500);
  };

  return (
    <div className="flex-1 bg-slate-50 h-full flex flex-col overflow-hidden">
      {/* Header */}
      <div className="px-4 pt-4 pb-2 bg-white border-b shadow-sm shrink-0">
        <div className="flex items-center justify-between">
          <Logo size={24} />
          <div className="flex gap-3">
            <Search className="w-5 h-5 text-gray-400" />
            <div className="w-7 h-7 bg-[#B5DEFF] rounded-full flex items-center justify-center text-white font-bold text-[10px] shadow-sm">U</div>
          </div>
        </div>
      </div>

      {/* URL Search Bar */}
      <div className="px-4 mt-2 shrink-0">
        <div className="bg-white p-4 rounded-[24px] shadow-lg shadow-slate-200/60 border border-white relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-16 h-16 bg-[#B5DEFF]/5 rounded-full -mr-8 -mt-8 group-hover:scale-150 transition-transform duration-700" />
          <h3 className="text-[9px] font-black text-slate-400 mb-2 ml-1 flex items-center gap-1.5 uppercase tracking-widest">
            <LinkIcon className="w-3 h-3 text-[#B5DEFF]" />
            Direct URL Analysis
          </h3>
          <div className="relative">
            <input
              type="text"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="쿠팡/네이버 상품 URL 붙여넣기"
              className="w-full pl-4 pr-18 py-2.5 bg-slate-50 rounded-lg border-2 border-transparent focus:border-[#B5DEFF]/20 focus:bg-white transition-all outline-none text-xs font-bold placeholder:text-slate-300 shadow-inner"
            />
            <button
              onClick={handleUrlAnalysis}
              disabled={isAnalyzing}
              className="absolute right-1.5 top-1/2 -translate-y-1/2 bg-[#B5DEFF] text-white px-3 py-1.5 rounded-md text-[9px] font-black shadow-lg shadow-[#B5DEFF]/30 active:scale-95 disabled:opacity-50 transition-all uppercase tracking-tighter"
            >
              {isAnalyzing ? "..." : "Analyze"}
            </button>
          </div>
        </div>
      </div>

      {/* Unified Action Section */}
      <div className="px-4 mt-2 shrink-0">
        <button
          onClick={() => navigate("/camera")}
          className="w-full bg-gradient-to-br from-[#E8F4FF] via-[#F1F7FF] to-[#F8FAFC] rounded-[24px] px-3 py-2.5 relative overflow-hidden shadow-md shadow-slate-200/60 group active:scale-[0.98] transition-all border border-slate-100"
        >
          <div className="relative z-10">
            <div className="flex items-center gap-2.5 mb-2 text-left">
              <div className="w-9 h-9 bg-[#B5DEFF] rounded-[12px] flex items-center justify-center shrink-0 group-hover:scale-110 group-hover:rotate-3 transition-transform duration-500 shadow-md shadow-[#B5DEFF]/30 border border-white">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <h2 className="text-sm font-black tracking-tight leading-tight text-slate-800">스마트 분석 센터</h2>
                <p className="text-slate-500 text-[9px] leading-tight font-medium">
                  AI가 <span className="text-[#5FA8CC] font-bold">최저가·구매 적기</span>를 알려드려요
                </p>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-1.5">
              <div className="bg-white rounded-[10px] p-1.5 flex flex-col items-center gap-0.5 border border-slate-100 hover:bg-slate-50 transition-colors shadow-sm">
                <div className="w-6 h-6 bg-[#B5DEFF]/15 rounded-md flex items-center justify-center">
                  <Camera className="w-3 h-3 text-[#5FA8CC]" />
                </div>
                <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest">CAMERA</span>
              </div>
              <div className="bg-white rounded-[10px] p-1.5 flex flex-col items-center gap-0.5 border border-slate-100 hover:bg-slate-50 transition-colors shadow-sm">
                <div className="w-6 h-6 bg-[#B5DEFF]/15 rounded-md flex items-center justify-center">
                  <Upload className="w-3 h-3 text-[#5FA8CC]" />
                </div>
                <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest">ALBUM</span>
              </div>
              <div className="bg-white rounded-[10px] p-1.5 flex flex-col items-center gap-0.5 border border-slate-100 hover:bg-slate-50 transition-colors shadow-sm">
                <div className="w-6 h-6 bg-[#B5DEFF]/15 rounded-md flex items-center justify-center">
                  <LinkIcon className="w-3 h-3 text-[#5FA8CC]" />
                </div>
                <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest">URL LINK</span>
              </div>
            </div>
          </div>

          <div className="absolute top-[-30%] right-[-15%] w-40 h-40 bg-[#B5DEFF]/15 rounded-full blur-3xl" />
        </button>
      </div>

      {/* Recent Searches Section */}
      <div className="px-4 mt-2 pb-2 flex-1 min-h-0 flex flex-col">
        <div className="flex items-center justify-between mb-2 px-1 shrink-0">
          <div className="flex items-center gap-1.5">
            <div className="w-0.5 h-4 bg-[#B5DEFF] rounded-full" />
            <h3 className="font-bold text-sm text-gray-900">히스토리 리포트</h3>
          </div>
          {history.length > 0 && (
            <button
              onClick={clearHistory}
              className="text-[9px] font-black text-gray-400 hover:text-red-400 transition-colors uppercase tracking-widest"
            >
              Clear all
            </button>
          )}
        </div>

        <div className="space-y-2 flex-1 min-h-0 overflow-auto">
          {history.length > 0 ? (
            history.map((item) => {
              const statusInfo = getPriceStatusInfo(item.priceStatus, item.currentPrice, item.prevPrice);
              const StatusIcon = statusInfo.icon;

              return (
                <Card
                  key={`${item.id}-${item.timestamp}`}
                  onClick={() => navigate(`/result/${item.id}`)}
                  className="p-2.5 border-none shadow-md shadow-slate-200/50 hover:shadow-lg hover:-translate-y-0.5 transition-all cursor-pointer rounded-[24px] group bg-white relative overflow-hidden"
                >
                  <div className="flex gap-2.5 relative z-10">
                    <div className="w-16 h-16 bg-slate-50 rounded-lg overflow-hidden flex-shrink-0 border border-slate-100 group-hover:scale-105 transition-transform duration-500 relative">
                      <ImageWithFallback
                        src={item.image}
                        alt={item.name}
                        className="w-full h-full object-cover grayscale-[0.2] group-hover:grayscale-0 transition-all"
                      />
                      {/* Price Status Small Indicator */}
                      <div className={`absolute top-1 left-1 w-1 h-1 rounded-full ${statusInfo.color.replace('text', 'bg')} shadow-[0_0_4px_rgba(0,0,0,0.1)] animate-pulse`} />
                    </div>

                    <div className="flex-1 min-w-0 flex flex-col justify-between">
                      <div>
                        <div className="flex items-center justify-between mb-0.5">
                          <div className="flex items-center gap-0.5">
                            <span className="text-[8px] font-black text-[#B5DEFF] tracking-tighter uppercase">{item.model}</span>
                            <span className="text-[6px] text-gray-300">•</span>
                            <span className="text-[7px] font-bold text-gray-400">
                              {formatDistanceToNow(item.timestamp, { addSuffix: true, locale: ko })}
                            </span>
                          </div>
                        </div>
                        <h4 className="font-bold text-gray-900 mb-0.5 truncate text-xs leading-tight group-hover:text-[#B5DEFF] transition-colors">{item.name}</h4>
                        <div className="flex items-baseline gap-0.5">
                          <span className="text-base font-black text-gray-900">
                            {item.currentPrice.toLocaleString()}
                          </span>
                          <span className="text-[8px] font-bold text-gray-400">원</span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between mt-1">
                        <div className={`flex items-center gap-0.5 px-2 py-0.5 rounded-[10px] ${statusInfo.bgColor} border border-white shadow-sm`}>
                          <StatusIcon className={`w-2 h-2 ${statusInfo.color}`} />
                          <span className={`text-[8px] font-black ${statusInfo.color} uppercase tracking-tight`}>
                            {statusInfo.label}
                          </span>
                        </div>
                        <span className="text-[7px] font-black text-slate-300 tracking-widest uppercase">AI {item.matchRate.toFixed(0)}%</span>
                      </div>
                    </div>
                  </div>

                  {/* Decorative element */}
                  <div className="absolute bottom-0 right-0 w-8 h-8 bg-gradient-to-br from-transparent to-[#B5DEFF]/5 rounded-tl-[24px]" />
                </Card>
              );
            })
          ) : (
            <div className="py-12 flex flex-col items-center justify-center text-center px-10">
              <div className="w-12 h-12 bg-gray-50 rounded-full flex items-center justify-center mb-2">
                <Search className="w-6 h-6 text-gray-200" />
              </div>
              <p className="text-gray-400 font-bold text-[11px] leading-relaxed">
                아직 분석 내역이 없습니다<br />
                상품 사진이나 링크를 등록해보세요!
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}