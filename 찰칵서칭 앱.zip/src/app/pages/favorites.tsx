import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { Heart, TrendingDown, TrendingUp, Minus, Bell, Trash2, ArrowRight } from "lucide-react";
import { Card } from "../components/ui/card";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import { products, getProductById } from "../data/products";
import { motion, AnimatePresence } from "motion/react";
import { toast } from "sonner";
import { Logo } from "../components/logo";

interface FavoriteItem {
  id: string;
  name: string;
  model: string;
  image: string;
  currentPrice: number;
  prevPrice: number;
  priceStatus: "low" | "average" | "high";
  savedDate: string;
}

const getPriceStatusInfo = (status: string, current: number, prev: number) => {
  const diff = current - prev;
  const isDown = diff < 0;
  
  switch (status) {
    case "low":
      return {
        label: "역대 최저가",
        color: "text-green-600",
        bgColor: "bg-green-50",
        icon: TrendingDown,
        desc: isDown ? `${Math.abs(diff).toLocaleString()}원 하락` : "최저가 유지중",
      };
    case "high":
      return {
        label: "가격 상승",
        color: "text-red-600",
        bgColor: "bg-red-50",
        icon: TrendingUp,
        desc: `${Math.abs(diff).toLocaleString()}원 상승`,
      };
    default:
      return {
        label: "평균가 유지",
        color: "text-slate-600",
        bgColor: "bg-slate-50",
        icon: Minus,
        desc: "변동폭 적음",
      };
  }
};

export function Favorites() {
  const navigate = useNavigate();
  const [favorites, setFavorites] = useState<FavoriteItem[]>([]);

  // LocalStorage에서 찜 목록 로드
  useEffect(() => {
    const saved = localStorage.getItem("user_favorites");
    if (saved) {
      setFavorites(JSON.parse(saved));
    } else {
      // 초기 데모를 위해 빈 상태로 시작하되, 
      // 만약 최근 분석한 제품이 있다면 그것을 보여줄 수도 있음
      setFavorites([]);
    }
  }, []);

  const handleRemoveFavorite = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = favorites.filter((item) => item.id !== id);
    setFavorites(updated);
    localStorage.setItem("user_favorites", JSON.stringify(updated));
    toast.success("찜한 목록에서 삭제되었습니다.");
  };

  return (
    <div className="h-full overflow-auto bg-slate-50 pb-14">
      {/* Header */}
      <div className="bg-white px-4 pt-6 pb-4 sticky top-0 z-30 border-b border-slate-100 shadow-sm">
        <div className="flex items-center justify-between mb-3">
          <Logo size={22} />
          <div className="w-8 h-8 bg-red-50 rounded-lg flex items-center justify-center">
            <Heart className="w-3.5 h-3.5 text-red-500 fill-red-500" />
          </div>
        </div>
        <div>
          <h1 className="text-lg font-black text-slate-900 tracking-tight">위시리스트</h1>
          <p className="text-[10px] font-black text-[#B5DEFF] uppercase tracking-widest mt-0.5">
            {favorites.length} items in your collection
          </p>
        </div>
      </div>

      {/* Favorites List */}
      <div className="px-4 py-3">
        <AnimatePresence mode="popLayout">
          {favorites.length > 0 ? (
            <div className="space-y-2">
              {favorites.map((item) => {
                const statusInfo = getPriceStatusInfo(item.priceStatus, item.currentPrice, item.prevPrice);
                const StatusIcon = statusInfo.icon;

                return (
                  <motion.div
                    key={item.id}
                    layout
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.9, x: -20 }}
                  >
                    <Card
                      onClick={() => navigate(`/result/${item.id}`)}
                      className="p-3 border-none shadow-md shadow-slate-200/50 hover:shadow-lg transition-all cursor-pointer rounded-[24px] bg-white group relative overflow-hidden"
                    >
                      <div className="flex gap-2.5 relative z-10">
                        {/* Image Section */}
                        <div className="w-18 h-18 bg-slate-50 rounded-[20px] overflow-hidden flex-shrink-0 border border-slate-100 group-hover:scale-105 transition-transform duration-500 relative">
                          <ImageWithFallback
                            src={item.image}
                            alt={item.name}
                            className="w-full h-full object-cover"
                          />
                          <div className={`absolute top-1 left-1 w-1 h-1 rounded-full ${statusInfo.color.replace('text', 'bg')} animate-pulse`} />
                        </div>

                        {/* Info Section */}
                        <div className="flex-1 min-w-0 flex flex-col justify-between">
                          <div>
                            <div className="flex items-center justify-between mb-0.5">
                              <span className="text-[8px] font-black text-[#B5DEFF] tracking-tighter uppercase">{item.model}</span>
                              <button
                                onClick={(e) => handleRemoveFavorite(item.id, e)}
                                className="p-1 bg-slate-50 rounded-md text-slate-300 hover:text-red-400 hover:bg-red-50 transition-all active:scale-90"
                              >
                                <Trash2 className="w-3 h-3" />
                              </button>
                            </div>
                            <h4 className="font-black text-slate-900 mb-0.5 truncate text-sm leading-tight group-hover:text-[#B5DEFF] transition-colors">{item.name}</h4>
                            <div className="flex items-baseline gap-0.5">
                              <span className="text-base font-black text-slate-900">
                                {item.currentPrice.toLocaleString()}
                              </span>
                              <span className="text-[9px] font-bold text-slate-400">원</span>
                            </div>
                          </div>

                          <div className="flex items-center justify-between mt-1">
                            <div className={`flex items-center gap-0.5 px-2 py-0.5 rounded-[10px] ${statusInfo.bgColor} border border-white shadow-sm`}>
                              <StatusIcon className={`w-2.5 h-2.5 ${statusInfo.color}`} />
                              <span className={`text-[8px] font-black ${statusInfo.color} uppercase tracking-tight`}>
                                {statusInfo.label}
                              </span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Bell className="w-2.5 h-2.5 text-slate-300" />
                              <span className="text-[8px] font-black text-slate-400 tracking-widest uppercase">{item.savedDate}</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* AI Monitoring Badge */}
                      <div className="absolute top-0 right-8 bg-slate-900 text-white text-[6px] font-black px-2 py-0.5 rounded-b-md uppercase tracking-widest opacity-80">
                        Live
                      </div>
                    </Card>
                  </motion.div>
                );
              })}
            </div>
          ) : (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex flex-col items-center justify-center py-16 px-10 text-center"
            >
              <div className="w-16 h-16 bg-white rounded-[28px] shadow-lg shadow-slate-200 flex items-center justify-center mb-4 relative">
                <Heart className="w-7 h-7 text-red-200 fill-red-100" />
                <div className="absolute inset-0 border-2 border-dashed border-slate-100 rounded-[28px] animate-[spin_10s_linear_infinite]" />
              </div>
              <h3 className="text-base font-black text-slate-900 mb-1.5 tracking-tight">
                위시리스트가 비어있습니다
              </h3>
              <p className="text-[11px] font-bold text-slate-400 leading-relaxed mb-6">
                관심 있는 제품의 가격 변동을<br />
                실시간으로 감시하고 알려드릴게요
              </p>
              <button
                onClick={() => navigate("/home")}
                className="w-full bg-[#B5DEFF] text-white h-12 rounded-[20px] font-black shadow-lg shadow-[#B5DEFF]/30 flex items-center justify-center gap-2 active:scale-95 transition-all uppercase tracking-widest text-[10px]"
              >
                Explore Products
                <ArrowRight className="w-3 h-3" />
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
