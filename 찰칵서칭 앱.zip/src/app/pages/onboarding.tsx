import { useState } from "react";
import { useNavigate } from "react-router";
import { Camera, TrendingDown, Sparkles } from "lucide-react";
import { Button } from "../components/ui/button";
import { motion } from "motion/react";
import { Logo } from "../components/logo";

const onboardingSlides = [
  {
    icon: Camera,
    title: "사진만 찍으면\n가격 분석 완료",
    description: "가전제품을 촬영하거나 사진을 업로드하면\nAI가 자동으로 제품을 인식합니다",
    color: "#B5DEFF",
  },
  {
    icon: TrendingDown,
    title: "쿠팡 가격\n실시간 분석",
    description: "현재 가격과 과거 데이터를 비교해서\n지금이 저렴한지 알려드립니다",
    color: "#B5DEFF",
  },
  {
    icon: Sparkles,
    title: "최적의 구매 시점을\n놓치지 마세요",
    description: "데이터 기반 분석으로\n스마트한 쇼핑을 시작하세요",
    color: "#B5DEFF",
  },
];

export function Onboarding() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const navigate = useNavigate();

  const handleNext = () => {
    if (currentSlide < onboardingSlides.length - 1) {
      setCurrentSlide(currentSlide + 1);
    } else {
      navigate("/home");
    }
  };

  const handleSkip = () => {
    navigate("/home");
  };

  const slide = onboardingSlides[currentSlide];
  const Icon = slide.icon;

  return (
    <div className="h-screen max-h-[852px] w-[393px] mx-auto bg-white flex flex-col overflow-hidden">
      {/* Top Row: Logo + Skip */}
      <div className="px-5 pt-4 pb-2 flex items-center justify-between shrink-0">
        <Logo size={24} />
        <button
          onClick={handleSkip}
          className="text-xs text-gray-400 hover:text-gray-600 font-medium"
        >
          건너뛰기
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 min-h-0 flex flex-col items-center justify-center px-6">
        <motion.div
          key={currentSlide}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex flex-col items-center text-center"
        >
          <div
            className="w-20 h-20 rounded-full flex items-center justify-center mb-6 bg-[#B5DEFF]/20"
          >
            <Icon className="w-10 h-10 text-[#B5DEFF]" />
          </div>

          <h1 className="text-xl font-semibold mb-2 whitespace-pre-line leading-snug">
            {slide.title}
          </h1>

          <p className="text-sm text-gray-500 leading-relaxed whitespace-pre-line">
            {slide.description}
          </p>
        </motion.div>
      </div>

      {/* Navigation */}
      <div className="px-6 pb-5 shrink-0">
        <div className="flex justify-center gap-2 mb-4">
          {onboardingSlides.map((_, index) => (
            <div
              key={index}
              className={`h-1.5 rounded-full transition-all ${
                index === currentSlide
                  ? "w-6 bg-[#B5DEFF]"
                  : "w-1.5 bg-gray-300"
              }`}
            />
          ))}
        </div>

        <Button
          onClick={handleNext}
          className="w-full bg-[#B5DEFF] hover:bg-[#B5DEFF] text-white h-12 rounded-xl text-sm font-bold hover:scale-[1.02] active:scale-[0.98] transition-transform"
        >
          {currentSlide === onboardingSlides.length - 1
            ? "시작하기"
            : "다음"}
        </Button>
      </div>
    </div>
  );
}