import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { Loader2, Sparkles, Search, TrendingUp, Cpu, Globe, Database } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { useSearchStore } from "../store/useSearchStore";
import { getProductById } from "../data/products";

const analysisSteps = [
  { icon: Search, text: "이미지 특징 추출 중...", delay: 0 },
  { icon: Globe, text: "주요 쇼핑몰 실시간 검색 중...", delay: 800 },
  { icon: Cpu, text: "AI 가격 데이터 비교 분석 중...", delay: 1600 },
  { icon: Database, text: "과거 가격 변동 추이 조회 중...", delay: 2400 },
];

export function Loading() {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(0);
  const addItem = useSearchStore((state) => state.addItem);

  useEffect(() => {
    const stepInterval = setInterval(() => {
      setCurrentStep((prev) => (prev < analysisSteps.length - 1 ? prev + 1 : prev));
    }, 1000);

    const timer = setTimeout(() => {
      const productId = localStorage.getItem("currentProductId") || "1";
      const product = getProductById(productId);
      
      if (product) {
        // 실제 분석된 데이터를 히스토리에 추가
        addItem({
          id: product.id,
          name: product.name,
          model: product.model,
          image: product.image,
          currentPrice: product.currentPrice,
          prevPrice: product.avgPrice, // 이전 가격(평균가)
          priceStatus: product.priceStatus,
          timestamp: Date.now(),
          matchRate: 98 + Math.random() * 1.9, // 98~99.9% 사이 랜덤
        });
      }
      
      navigate(`/result/${productId}`, { replace: true });
    }, 4500);

    return () => {
      clearInterval(stepInterval);
      clearTimeout(timer);
    };
  }, [navigate, addItem]);

  return (
    <div className="h-screen max-h-[852px] w-[393px] mx-auto bg-white flex flex-col items-center justify-center px-6 py-4 overflow-hidden">
      <div className="w-full text-center">
        {/* Animated Scanner Ring */}
        <div className="relative w-32 h-32 mx-auto mb-6">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
            className="absolute inset-0 rounded-full border-2 border-dashed border-[#B5DEFF]/30"
          />
          <motion.div
            animate={{ rotate: -360 }}
            transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
            className="absolute inset-4 rounded-full border-2 border-[#B5DEFF] border-t-transparent"
          />
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <motion.div
              animate={{ 
                scale: [1, 1.1, 1],
                opacity: [0.8, 1, 0.8] 
              }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <Sparkles className="w-8 h-8 text-[#B5DEFF] mb-1" />
            </motion.div>
            <span className="text-[10px] font-bold text-[#B5DEFF] tracking-[0.2em] uppercase">Analyzing</span>
          </div>
          
          {/* Scanning particles */}
          {[...Array(6)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-1.5 h-1.5 bg-[#B5DEFF] rounded-full"
              animate={{
                top: ["20%", "80%", "20%"],
                left: ["20%", "80%", "20%"],
                opacity: [0, 1, 0]
              }}
              transition={{
                duration: 2,
                delay: i * 0.3,
                repeat: Infinity
              }}
              style={{
                top: `${20 + Math.random() * 60}%`,
                left: `${20 + Math.random() * 60}%`,
              }}
            />
          ))}
        </div>

        {/* Title */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-5"
        >
          <h2 className="text-base font-bold text-gray-800 mb-1">최적의 가격을 찾는 중</h2>
          <p className="text-[11px] text-gray-500">잠시만 기다려주시면 분석이 완료됩니다</p>
        </motion.div>

        {/* Progress Steps */}
        <div className="space-y-1.5 w-full max-w-[260px] mx-auto text-left">
          {analysisSteps.map((step, index) => {
            const Icon = step.icon;
            const isActive = currentStep >= index;
            const isCompleted = currentStep > index;

            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -10 }}
                animate={{ 
                  opacity: isActive ? 1 : 0.4,
                  x: 0,
                  scale: isActive ? 1 : 0.98
                }}
                className={`flex items-center gap-2.5 p-2 rounded-xl transition-all ${
                  isActive ? 'bg-gray-50 border border-gray-100 shadow-sm' : 'bg-transparent'
                }`}
              >
                <div className={`w-7 h-7 rounded-lg flex items-center justify-center transition-colors ${
                  isActive ? 'bg-[#B5DEFF] text-white' : 'bg-gray-100 text-gray-400'
                }`}>
                  {isCompleted ? (
                    <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }}>
                      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
                    </motion.div>
                  ) : (
                    <Icon className={`w-4 h-4 ${isActive && !isCompleted ? 'animate-pulse' : ''}`} />
                  )}
                </div>
                <span className={`text-[11px] font-bold transition-colors ${
                  isActive ? 'text-gray-800' : 'text-gray-400'
                }`}>
                  {step.text}
                </span>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}