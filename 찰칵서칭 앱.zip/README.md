
  # 찰칵서칭 앱

  This is a code bundle for 찰칵서칭 앱. The original project is available at https://www.figma.com/design/gYfUWc50XQt10aLzAU9aP1/%EC%B0%B0%EC%B9%B5%EC%84%9C%EC%B9%AD-%EC%95%B1.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  