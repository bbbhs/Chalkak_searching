import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";

const app = new Hono();

app.use("*", logger(console.log));
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

app.get("/make-server-390d39c1/health", (c) => {
  return c.json({ status: "ok" });
});

// ─── Gemini Vision 이미지 인식 ───────────────────────────────────────────────
// POST /make-server-390d39c1/recognize
// body: { image: "data:image/jpeg;base64,..." }
// returns: { id: string, confidence: number, category: string }
const CATEGORY_MAP = `
가전제품 종류 → 카탈로그 ID 매핑:
- 공기청정기 (air purifier) → ID 1 (LG) 또는 ID 5 (Xiaomi/샤오미, 더 작고 원통형)
- 로봇청소기 (robot vacuum) → ID 2 (Roborock, 도킹스테이션 있음), ID 8 (iRobot Roomba, 원형), ID 13 (Samsung 제트봇)
- 헤어스타일러 / 드라이어 (hair styler/dryer) → ID 3 (Dyson Airwrap, 원통형 멀티툴)
- 냉장고 (refrigerator/fridge) → ID 4 (Samsung Bespoke 4도어)
- 에어프라이어 (air fryer) → ID 6 (Philips, 검은색 바구니형)
- 정수기 (water purifier/dispenser) → ID 7 (Coway, 슬림 직수형)
- 건조기 (clothes dryer) → ID 9 (LG Tromm, 대형 드럼)
- 에어컨 (air conditioner, 벽걸이/스탠드) → ID 10 (Samsung 무풍)
- 커피머신 / 에스프레소 머신 (coffee/espresso machine) → ID 11 (Breville)
- 밥솥 / 압력솥 (rice cooker) → ID 12 (Cuckoo)
- 식기세척기 (dishwasher) → ID 14 (LG 오브제)
- 인덕션 / 전기레인지 (induction cooktop) → ID 15 (Tefal)
- 제습기 (dehumidifier) → ID 16 (Winix)
- 무선청소기 / 스틱청소기 (cordless vacuum) → ID 17 (Electrolux)
- 전기면도기 (electric shaver/razor) → ID 18 (Braun)
- 착즙기 / 주서 (juicer/slow juicer) → ID 19 (Kuvings/쿠잉)
- 블렌더 / 믹서 (blender) → ID 20 (Vitamix)
`.trim();

app.post("/make-server-390d39c1/recognize", async (c) => {
  const apiKey = Deno.env.get("VITE_GEMINI_API_KEY");
  if (!apiKey) {
    return c.json({ error: "GEMINI_API_KEY not configured" }, 500);
  }

  const body = await c.req.json() as { image?: string };
  if (!body.image) {
    return c.json({ error: "image required" }, 400);
  }

  // data URL에서 mimeType과 base64 분리
  const match = body.image.match(/^data:([^;]+);base64,(.+)$/);
  if (!match) {
    return c.json({ error: "invalid image format" }, 400);
  }
  const mimeType = match[1];
  const base64Data = match[2];

  const prompt = `당신은 가전제품 인식 전문가입니다.
이미지에 나타난 가전제품의 종류를 파악하고, 아래 매핑표에서 가장 적합한 ID를 선택하세요.

${CATEGORY_MAP}

판단 기준:
1. 제품의 전체적인 형태와 용도를 먼저 파악하세요
2. 브랜드 로고나 모델명이 보이면 추가 힌트로 활용하세요
3. 확실하지 않으면 시각적으로 가장 유사한 카테고리를 선택하세요

반드시 아래 JSON 형식으로만 답변하세요 (다른 텍스트 절대 금지):
{"id":"<1~20 중 하나>","confidence":<50~99 정수>,"category":"<인식한 가전 종류 한국어>"}`;

  const geminiRes = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{
          parts: [
            { inline_data: { mime_type: mimeType, data: base64Data } },
            { text: prompt },
          ],
        }],
        generationConfig: { temperature: 0.1, maxOutputTokens: 128 },
      }),
    }
  );

  if (!geminiRes.ok) {
    const err = await geminiRes.text();
    console.error("Gemini error:", err);
    return c.json({ error: "Gemini API error", detail: err }, 502);
  }

  const geminiData = await geminiRes.json() as {
    candidates?: { content?: { parts?: { text?: string }[] } }[];
  };

  const text = geminiData.candidates?.[0]?.content?.parts?.[0]?.text ?? "";
  const jsonMatch = text.match(/\{[\s\S]*?\}/);
  if (!jsonMatch) {
    return c.json({ error: "parse failed", raw: text }, 502);
  }

  const parsed = JSON.parse(jsonMatch[0]) as {
    id: string;
    confidence: number;
    category: string;
  };

  return c.json({
    id: String(parsed.id),
    confidence: Math.min(99.9, Math.max(60, parsed.confidence)),
    category: parsed.category ?? "",
  });
});

// ─── 네이버 쇼핑 가격 조회 ────────────────────────────────────────────────────
app.get("/make-server-390d39c1/price/:productId", async (c) => {
  const productId = c.req.param("productId");
  const name = c.req.query("name") ?? "";
  const model = c.req.query("model") ?? "";

  const clientId = Deno.env.get("NAVER_CLIENT_ID");
  const clientSecret = Deno.env.get("NAVER_CLIENT_SECRET");

  if (!clientId || !clientSecret) {
    const history = (await kv.get(`price_history:${productId}`)) ?? [];
    return c.json({ currentPrice: null, priceHistory: history, source: "cache_only" });
  }

  const query = encodeURIComponent(`${name} ${model}`.trim());
  const naverUrl = `https://openapi.naver.com/v1/search/shop.json?query=${query}&display=5&sort=sim`;

  let currentPrice: number | null = null;

  try {
    const res = await fetch(naverUrl, {
      headers: {
        "X-Naver-Client-Id": clientId,
        "X-Naver-Client-Secret": clientSecret,
      },
    });
    if (res.ok) {
      const data = await res.json() as { items?: { lprice?: string }[] };
      const prices = (data.items ?? [])
        .map((i) => parseInt(i.lprice ?? "0", 10))
        .filter((p) => p > 0);
      if (prices.length > 0) currentPrice = Math.min(...prices);
    }
  } catch (e) {
    console.error("Naver API error:", e);
  }

  const today = new Date()
    .toLocaleDateString("ko-KR", { month: "2-digit", day: "2-digit" })
    .replace(". ", "/").replace(".", "");
  const history: { date: string; price: number }[] =
    (await kv.get(`price_history:${productId}`)) ?? [];

  if (currentPrice !== null) {
    const todayIndex = history.findIndex((h) => h.date === today);
    if (todayIndex >= 0) history[todayIndex].price = currentPrice;
    else history.push({ date: today, price: currentPrice });
    if (history.length > 30) history.splice(0, history.length - 30);
    await kv.set(`price_history:${productId}`, history);
  }

  return c.json({ currentPrice, priceHistory: history, source: "naver" });
});

Deno.serve(app.fetch);
